class ABC:
employeeid=0
name=""
designation=""
department=""
def _init_(self):
    id=int(input("Enter employeeid"))
    name=input("Enter employee name")
    desig=input("Enter employee department")
    self ._employeeid=id
    self ._name=name
    self ._designation=desig
    self ._department=depart
    sal=c.dSalary(self)
    self.NetSal=sal
    print("net salary is" ,self.NetSal)
    class p=D()
    class p.displayed()
